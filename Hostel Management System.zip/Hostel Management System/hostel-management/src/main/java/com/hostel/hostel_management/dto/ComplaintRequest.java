package com.hostel.hostel_management.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ComplaintRequest {

    @NotBlank(message = "Complaint description is required")
    private String description;
}
