package com.hostel.hostel_management.repository;

import com.hostel.hostel_management.model.Complaint;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ComplaintRepository extends MongoRepository<Complaint, String> {

    List<Complaint> findByStudentId(String studentId);
}
