package com.hostel.hostel_management.service.impl;

import com.hostel.hostel_management.dto.ComplaintRequest;
import com.hostel.hostel_management.exception.ResourceNotFoundException;
import com.hostel.hostel_management.model.Complaint;
import com.hostel.hostel_management.model.ComplaintStatus;
import com.hostel.hostel_management.repository.ComplaintRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.service.ComplaintService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplaintServiceImpl implements ComplaintService {

    private static final ComplaintStatus DEFAULT_STATUS = ComplaintStatus.OPEN;

    private final ComplaintRepository complaintRepository;
    private final StudentRepository studentRepository;

    @Override
    public Complaint createComplaint(Complaint complaint) {
        validateStudent(complaint.getStudentId());
        if (complaint.getStatus() == null) {
            complaint.setStatus(DEFAULT_STATUS);
        }
        return complaintRepository.save(complaint);
    }

    @Override
    public Page<Complaint> getAllComplaints(Pageable pageable) {
        return complaintRepository.findAll(pageable);
    }

    @Override
    public Complaint getComplaintById(String id) {
        return findComplaint(id);
    }

    @Override
    public Complaint updateComplaintStatus(String id, ComplaintStatus status) {
        Complaint complaint = findComplaint(id);
        complaint.setStatus(status);
        return complaintRepository.save(complaint);
    }

    @Override
    public void deleteComplaint(String id) {
        complaintRepository.delete(findComplaint(id));
    }

    @Override
    public Complaint raiseComplaint(String studentId, ComplaintRequest request) {
        validateStudent(studentId);
        Complaint complaint = Complaint.builder()
                .description(request.getDescription())
                .status(DEFAULT_STATUS)
                .studentId(studentId)
                .build();
        return complaintRepository.save(complaint);
    }

    @Override
    public List<Complaint> getComplaintsByStudent(String studentId) {
        validateStudent(studentId);
        return complaintRepository.findByStudentId(studentId);
    }

    private Complaint findComplaint(String id) {
        return complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found with id: " + id));
    }

    private void validateStudent(String studentId) {
        if (!studentRepository.existsById(studentId)) {
            throw new ResourceNotFoundException("Student not found with id: " + studentId);
        }
    }
}
