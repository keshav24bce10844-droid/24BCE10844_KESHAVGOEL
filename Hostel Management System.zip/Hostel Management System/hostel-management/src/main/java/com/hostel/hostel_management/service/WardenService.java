package com.hostel.hostel_management.service;

import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Warden;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface WardenService {

    Warden createWarden(Warden warden);

    Page<Warden> getAllWardens(Pageable pageable);

    Warden getWardenById(String id);

    Warden updateWarden(String id, Warden warden);

    void deleteWarden(String id);

    List<Room> getRoomsByWarden(String wardenId);
}
