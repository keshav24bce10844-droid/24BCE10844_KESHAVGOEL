package com.hostel.hostel_management.dto;

import com.hostel.hostel_management.model.ComplaintStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ComplaintStatusUpdateRequest {

    @NotNull(message = "Complaint status is required")
    private ComplaintStatus status;
}
