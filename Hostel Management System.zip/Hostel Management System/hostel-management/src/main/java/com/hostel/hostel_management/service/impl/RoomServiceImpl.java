package com.hostel.hostel_management.service.impl;

import com.hostel.hostel_management.exception.BadRequestException;
import com.hostel.hostel_management.exception.ResourceNotFoundException;
import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Student;
import com.hostel.hostel_management.repository.RoomRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.repository.WardenRepository;
import com.hostel.hostel_management.service.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;
    private final StudentRepository studentRepository;
    private final WardenRepository wardenRepository;

    @Override
    public Room createRoom(Room room) {
        validateWarden(room.getWardenId());
        validateRoomCapacity(room);
        if (room.getOccupiedBeds() == null) {
            room.setOccupiedBeds(0);
        }
        return roomRepository.save(room);
    }

    @Override
    public Page<Room> getAllRooms(Pageable pageable) {
        return roomRepository.findAll(pageable);
    }

    @Override
    public Room getRoomById(String id) {
        return findRoom(id);
    }

    @Override
    public Room updateRoom(String id, Room room) {
        Room existingRoom = findRoom(id);
        validateWarden(room.getWardenId());
        validateRoomCapacity(room);

        int occupiedBeds = room.getOccupiedBeds() == null ? existingRoom.getOccupiedBeds() : room.getOccupiedBeds();
        if (occupiedBeds > room.getCapacity()) {
            throw new BadRequestException("Occupied beds cannot be greater than room capacity");
        }

        existingRoom.setRoomNumber(room.getRoomNumber());
        existingRoom.setCapacity(room.getCapacity());
        existingRoom.setOccupiedBeds(occupiedBeds);
        existingRoom.setWardenId(room.getWardenId());
        return roomRepository.save(existingRoom);
    }

    @Override
    public void deleteRoom(String id) {
        Room room = findRoom(id);
        if (!studentRepository.findByRoomId(id).isEmpty()) {
            throw new BadRequestException("Cannot delete room while students are allocated to it");
        }
        roomRepository.delete(room);
    }

    @Override
    public List<Student> getStudentsByRoom(String roomId) {
        findRoom(roomId);
        return studentRepository.findByRoomId(roomId);
    }

    private Room findRoom(String id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + id));
    }

    private void validateWarden(String wardenId) {
        if (!wardenRepository.existsById(wardenId)) {
            throw new ResourceNotFoundException("Warden not found with id: " + wardenId);
        }
    }

    private void validateRoomCapacity(Room room) {
        int occupiedBeds = room.getOccupiedBeds() == null ? 0 : room.getOccupiedBeds();
        if (occupiedBeds > room.getCapacity()) {
            throw new BadRequestException("Occupied beds cannot be greater than room capacity");
        }
    }
}
