package com.hostel.hostel_management.service.impl;

import com.hostel.hostel_management.exception.BadRequestException;
import com.hostel.hostel_management.exception.ResourceNotFoundException;
import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Student;
import com.hostel.hostel_management.repository.DepartmentRepository;
import com.hostel.hostel_management.repository.RoomRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;
    private final RoomRepository roomRepository;
    private final DepartmentRepository departmentRepository;

    @Override
    public Student createStudent(Student student) {
        validateDepartmentIfPresent(student.getDepartmentId());
        String roomId = student.getRoomId();
        student.setRoomId(null);
        Student savedStudent = studentRepository.save(student);
        if (hasText(roomId)) {
            return allocateStudentToRoom(savedStudent.getId(), roomId);
        }
        return savedStudent;
    }

    @Override
    public Page<Student> getAllStudents(Pageable pageable) {
        return studentRepository.findAll(pageable);
    }

    @Override
    public Student getStudentById(String id) {
        return findStudent(id);
    }

    @Override
    public Student updateStudent(String id, Student student) {
        Student existingStudent = findStudent(id);
        existingStudent.setName(student.getName());
        existingStudent.setEmail(student.getEmail());
        existingStudent.setPhone(student.getPhone());
        validateDepartmentIfPresent(student.getDepartmentId());
        existingStudent.setDepartmentId(student.getDepartmentId());

        String newRoomId = student.getRoomId();
        String currentRoomId = existingStudent.getRoomId();
        if (!Objects.equals(currentRoomId, newRoomId)) {
            if (hasText(currentRoomId)) {
                decrementOccupiedBeds(currentRoomId);
            }
            existingStudent.setRoomId(null);
            studentRepository.save(existingStudent);
            if (hasText(newRoomId)) {
                return allocateStudentToRoom(existingStudent.getId(), newRoomId);
            }
        }

        return studentRepository.save(existingStudent);
    }

    @Override
    public void deleteStudent(String id) {
        Student student = findStudent(id);
        if (hasText(student.getRoomId())) {
            decrementOccupiedBeds(student.getRoomId());
        }
        studentRepository.delete(student);
    }

    @Override
    public Student allocateStudentToRoom(String studentId, String roomId) {
        Student student = findStudent(studentId);
        Room targetRoom = findRoom(roomId);
        String currentRoomId = student.getRoomId();

        if (Objects.equals(currentRoomId, roomId)) {
            return student;
        }

        if (isRoomFull(targetRoom)) {
            throw new BadRequestException("Room capacity exceeded for room " + targetRoom.getRoomNumber());
        }

        if (hasText(currentRoomId)) {
            decrementOccupiedBeds(currentRoomId);
        }

        targetRoom.setOccupiedBeds(normalizeOccupiedBeds(targetRoom) + 1);
        roomRepository.save(targetRoom);

        student.setRoomId(roomId);
        return studentRepository.save(student);
    }

    @Override
    public List<Student> getStudentsByRoom(String roomId) {
        findRoom(roomId);
        return studentRepository.findByRoomId(roomId);
    }

    private Student findStudent(String id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
    }

    private Room findRoom(String id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + id));
    }

    private void decrementOccupiedBeds(String roomId) {
        Room room = findRoom(roomId);
        int occupiedBeds = Math.max(0, normalizeOccupiedBeds(room) - 1);
        room.setOccupiedBeds(occupiedBeds);
        roomRepository.save(room);
    }

    private boolean isRoomFull(Room room) {
        return normalizeOccupiedBeds(room) >= room.getCapacity();
    }

    private int normalizeOccupiedBeds(Room room) {
        return room.getOccupiedBeds() == null ? 0 : room.getOccupiedBeds();
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private void validateDepartmentIfPresent(String departmentId) {
        if (hasText(departmentId) && !departmentRepository.existsById(departmentId)) {
            throw new ResourceNotFoundException("Department not found with id: " + departmentId);
        }
    }
}
