package com.hostel.hostel_management.service;

import com.hostel.hostel_management.model.Book;
import com.hostel.hostel_management.model.Staff;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface StaffService {

    Staff createStaff(Staff staff);

    Page<Staff> getAllStaff(Pageable pageable);

    Staff getStaffById(String id);

    Staff updateStaff(String id, Staff staff);

    void deleteStaff(String id);

    List<Book> getBooksAssignedToStaff(String staffId);
}
