package com.hostel.hostel_management.repository;

import com.hostel.hostel_management.model.Book;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface BookRepository extends MongoRepository<Book, String> {

    List<Book> findByIssuedStudentIdsContaining(String studentId);

    List<Book> findByAssignedStaffIdsContaining(String staffId);
}
