package com.hostel.hostel_management.service;

import com.hostel.hostel_management.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface StudentService {

    Student createStudent(Student student);

    Page<Student> getAllStudents(Pageable pageable);

    Student getStudentById(String id);

    Student updateStudent(String id, Student student);

    void deleteStudent(String id);

    Student allocateStudentToRoom(String studentId, String roomId);

    List<Student> getStudentsByRoom(String roomId);
}
