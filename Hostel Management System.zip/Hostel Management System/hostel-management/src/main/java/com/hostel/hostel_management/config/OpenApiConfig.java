package com.hostel.hostel_management.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI hostelManagementOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("Hostel Management System API")
                        .version("1.0.0")
                        .description("Backend APIs for managing students, rooms, wardens, and complaints."));
    }
}
