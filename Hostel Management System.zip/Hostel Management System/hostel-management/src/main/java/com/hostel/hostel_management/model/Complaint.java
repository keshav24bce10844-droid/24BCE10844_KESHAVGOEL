package com.hostel.hostel_management.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "complaints")
public class Complaint {

    @Id
    private String id;

    @NotBlank(message = "Complaint description is required")
    private String description;

    @NotNull(message = "Complaint status is required")
    private ComplaintStatus status;

    @NotBlank(message = "Student id is required")
    private String studentId;
}
