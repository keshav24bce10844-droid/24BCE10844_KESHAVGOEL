package com.hostel.hostel_management.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "wardens")
public class Warden {

    @Id
    private String id;

    @NotBlank(message = "Warden name is required")
    private String name;

    @NotBlank(message = "Warden phone is required")
    private String phone;

    @NotBlank(message = "Warden email is required")
    @Email(message = "Warden email must be valid")
    private String email;

    private String staffId;
}
