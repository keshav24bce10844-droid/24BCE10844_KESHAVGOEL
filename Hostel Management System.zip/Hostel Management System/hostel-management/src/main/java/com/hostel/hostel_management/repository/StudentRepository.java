package com.hostel.hostel_management.repository;

import com.hostel.hostel_management.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface StudentRepository extends MongoRepository<Student, String> {

    List<Student> findByRoomId(String roomId);

    List<Student> findByDepartmentId(String departmentId);
}
