package com.hostel.hostel_management.service;

import com.hostel.hostel_management.dto.ComplaintRequest;
import com.hostel.hostel_management.model.Complaint;
import com.hostel.hostel_management.model.ComplaintStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ComplaintService {

    Complaint createComplaint(Complaint complaint);

    Page<Complaint> getAllComplaints(Pageable pageable);

    Complaint getComplaintById(String id);

    Complaint updateComplaintStatus(String id, ComplaintStatus status);

    void deleteComplaint(String id);

    Complaint raiseComplaint(String studentId, ComplaintRequest request);

    List<Complaint> getComplaintsByStudent(String studentId);
}
