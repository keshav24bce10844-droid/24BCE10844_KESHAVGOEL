package com.hostel.hostel_management.repository;

import com.hostel.hostel_management.model.Department;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DepartmentRepository extends MongoRepository<Department, String> {
}
