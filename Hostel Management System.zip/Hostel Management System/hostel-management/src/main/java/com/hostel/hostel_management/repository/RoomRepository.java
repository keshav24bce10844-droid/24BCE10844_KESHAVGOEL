package com.hostel.hostel_management.repository;

import com.hostel.hostel_management.model.Room;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface RoomRepository extends MongoRepository<Room, String> {

    List<Room> findByWardenId(String wardenId);
}
