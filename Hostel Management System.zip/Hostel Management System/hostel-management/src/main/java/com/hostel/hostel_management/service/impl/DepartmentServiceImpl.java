package com.hostel.hostel_management.service.impl;

import com.hostel.hostel_management.exception.BadRequestException;
import com.hostel.hostel_management.exception.ResourceNotFoundException;
import com.hostel.hostel_management.model.Department;
import com.hostel.hostel_management.model.Staff;
import com.hostel.hostel_management.model.Student;
import com.hostel.hostel_management.repository.DepartmentRepository;
import com.hostel.hostel_management.repository.StaffRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final StudentRepository studentRepository;
    private final StaffRepository staffRepository;

    @Override
    public Department createDepartment(Department department) {
        return departmentRepository.save(department);
    }

    @Override
    public Page<Department> getAllDepartments(Pageable pageable) {
        return departmentRepository.findAll(pageable);
    }

    @Override
    public Department getDepartmentById(String id) {
        return findDepartment(id);
    }

    @Override
    public Department updateDepartment(String id, Department department) {
        Department existingDepartment = findDepartment(id);
        existingDepartment.setName(department.getName());
        existingDepartment.setCode(department.getCode());
        return departmentRepository.save(existingDepartment);
    }

    @Override
    public void deleteDepartment(String id) {
        Department department = findDepartment(id);
        if (!studentRepository.findByDepartmentId(id).isEmpty() || !staffRepository.findByDepartmentId(id).isEmpty()) {
            throw new BadRequestException("Cannot delete department while students or staff are assigned to it");
        }
        departmentRepository.delete(department);
    }

    @Override
    public List<Student> getStudentsByDepartment(String departmentId) {
        findDepartment(departmentId);
        return studentRepository.findByDepartmentId(departmentId);
    }

    @Override
    public List<Staff> getStaffByDepartment(String departmentId) {
        findDepartment(departmentId);
        return staffRepository.findByDepartmentId(departmentId);
    }

    private Department findDepartment(String id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + id));
    }
}
