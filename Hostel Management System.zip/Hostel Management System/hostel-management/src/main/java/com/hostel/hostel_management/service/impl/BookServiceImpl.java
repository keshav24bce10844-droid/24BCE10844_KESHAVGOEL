package com.hostel.hostel_management.service.impl;

import com.hostel.hostel_management.exception.BadRequestException;
import com.hostel.hostel_management.exception.ResourceNotFoundException;
import com.hostel.hostel_management.model.Book;
import com.hostel.hostel_management.repository.BookRepository;
import com.hostel.hostel_management.repository.StaffRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final StudentRepository studentRepository;
    private final StaffRepository staffRepository;

    @Override
    public Book createBook(Book book) {
        normalizeSets(book);
        validateCopies(book);
        return bookRepository.save(book);
    }

    @Override
    public Page<Book> getAllBooks(Pageable pageable) {
        return bookRepository.findAll(pageable);
    }

    @Override
    public Book getBookById(String id) {
        return findBook(id);
    }

    @Override
    public Book updateBook(String id, Book book) {
        Book existingBook = findBook(id);
        normalizeSets(book);
        validateCopies(book);
        existingBook.setTitle(book.getTitle());
        existingBook.setAuthor(book.getAuthor());
        existingBook.setIsbn(book.getIsbn());
        existingBook.setTotalCopies(book.getTotalCopies());
        existingBook.setIssuedStudentIds(book.getIssuedStudentIds());
        existingBook.setAssignedStaffIds(book.getAssignedStaffIds());
        return bookRepository.save(existingBook);
    }

    @Override
    public void deleteBook(String id) {
        bookRepository.delete(findBook(id));
    }

    @Override
    public Book issueBookToStudent(String bookId, String studentId) {
        Book book = findBook(bookId);
        validateStudent(studentId);
        normalizeSets(book);
        if (book.getIssuedStudentIds().contains(studentId)) {
            return book;
        }
        if (book.getIssuedStudentIds().size() >= book.getTotalCopies()) {
            throw new BadRequestException("No copies available for book: " + book.getTitle());
        }
        book.getIssuedStudentIds().add(studentId);
        return bookRepository.save(book);
    }

    @Override
    public Book returnBookFromStudent(String bookId, String studentId) {
        Book book = findBook(bookId);
        validateStudent(studentId);
        normalizeSets(book);
        book.getIssuedStudentIds().remove(studentId);
        return bookRepository.save(book);
    }

    @Override
    public Book assignBookToStaff(String bookId, String staffId) {
        Book book = findBook(bookId);
        validateStaff(staffId);
        normalizeSets(book);
        book.getAssignedStaffIds().add(staffId);
        return bookRepository.save(book);
    }

    @Override
    public Book unassignBookFromStaff(String bookId, String staffId) {
        Book book = findBook(bookId);
        validateStaff(staffId);
        normalizeSets(book);
        book.getAssignedStaffIds().remove(staffId);
        return bookRepository.save(book);
    }

    @Override
    public List<Book> getBooksIssuedToStudent(String studentId) {
        validateStudent(studentId);
        return bookRepository.findByIssuedStudentIdsContaining(studentId);
    }

    private Book findBook(String id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));
    }

    private void validateStudent(String studentId) {
        if (!studentRepository.existsById(studentId)) {
            throw new ResourceNotFoundException("Student not found with id: " + studentId);
        }
    }

    private void validateStaff(String staffId) {
        if (!staffRepository.existsById(staffId)) {
            throw new ResourceNotFoundException("Staff not found with id: " + staffId);
        }
    }

    private void validateCopies(Book book) {
        if (book.getIssuedStudentIds().size() > book.getTotalCopies()) {
            throw new BadRequestException("Issued copies cannot be greater than total copies");
        }
    }

    private void normalizeSets(Book book) {
        if (book.getIssuedStudentIds() == null) {
            book.setIssuedStudentIds(new HashSet<>());
        }
        if (book.getAssignedStaffIds() == null) {
            book.setAssignedStaffIds(new HashSet<>());
        }
    }
}
