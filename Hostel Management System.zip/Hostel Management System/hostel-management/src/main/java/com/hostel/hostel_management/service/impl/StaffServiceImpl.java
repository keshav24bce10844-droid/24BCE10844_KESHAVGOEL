package com.hostel.hostel_management.service.impl;

import com.hostel.hostel_management.exception.ResourceNotFoundException;
import com.hostel.hostel_management.model.Book;
import com.hostel.hostel_management.model.Staff;
import com.hostel.hostel_management.repository.BookRepository;
import com.hostel.hostel_management.repository.DepartmentRepository;
import com.hostel.hostel_management.repository.StaffRepository;
import com.hostel.hostel_management.service.StaffService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StaffServiceImpl implements StaffService {

    private final StaffRepository staffRepository;
    private final DepartmentRepository departmentRepository;
    private final BookRepository bookRepository;

    @Override
    public Staff createStaff(Staff staff) {
        validateDepartment(staff.getDepartmentId());
        return staffRepository.save(staff);
    }

    @Override
    public Page<Staff> getAllStaff(Pageable pageable) {
        return staffRepository.findAll(pageable);
    }

    @Override
    public Staff getStaffById(String id) {
        return findStaff(id);
    }

    @Override
    public Staff updateStaff(String id, Staff staff) {
        Staff existingStaff = findStaff(id);
        validateDepartment(staff.getDepartmentId());
        existingStaff.setName(staff.getName());
        existingStaff.setPhone(staff.getPhone());
        existingStaff.setEmail(staff.getEmail());
        existingStaff.setRole(staff.getRole());
        existingStaff.setDepartmentId(staff.getDepartmentId());
        return staffRepository.save(existingStaff);
    }

    @Override
    public void deleteStaff(String id) {
        staffRepository.delete(findStaff(id));
    }

    @Override
    public List<Book> getBooksAssignedToStaff(String staffId) {
        findStaff(staffId);
        return bookRepository.findByAssignedStaffIdsContaining(staffId);
    }

    private Staff findStaff(String id) {
        return staffRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Staff not found with id: " + id));
    }

    private void validateDepartment(String departmentId) {
        if (!departmentRepository.existsById(departmentId)) {
            throw new ResourceNotFoundException("Department not found with id: " + departmentId);
        }
    }
}
