package com.hostel.hostel_management.service;

import com.hostel.hostel_management.model.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface BookService {

    Book createBook(Book book);

    Page<Book> getAllBooks(Pageable pageable);

    Book getBookById(String id);

    Book updateBook(String id, Book book);

    void deleteBook(String id);

    Book issueBookToStudent(String bookId, String studentId);

    Book returnBookFromStudent(String bookId, String studentId);

    Book assignBookToStaff(String bookId, String staffId);

    Book unassignBookFromStaff(String bookId, String staffId);

    List<Book> getBooksIssuedToStudent(String studentId);
}
