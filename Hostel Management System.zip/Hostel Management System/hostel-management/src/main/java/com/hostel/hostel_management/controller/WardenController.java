package com.hostel.hostel_management.controller;

import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Warden;
import com.hostel.hostel_management.service.WardenService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/wardens")
@RequiredArgsConstructor
public class WardenController {

    private final WardenService wardenService;

    @PostMapping
    public ResponseEntity<Warden> createWarden(@Valid @RequestBody Warden warden) {
        return ResponseEntity.status(HttpStatus.CREATED).body(wardenService.createWarden(warden));
    }

    @GetMapping
    public ResponseEntity<Page<Warden>> getAllWardens(Pageable pageable) {
        return ResponseEntity.ok(wardenService.getAllWardens(pageable));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Warden> getWardenById(@PathVariable String id) {
        return ResponseEntity.ok(wardenService.getWardenById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Warden> updateWarden(@PathVariable String id, @Valid @RequestBody Warden warden) {
        return ResponseEntity.ok(wardenService.updateWarden(id, warden));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWarden(@PathVariable String id) {
        wardenService.deleteWarden(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{wardenId}/rooms")
    public ResponseEntity<List<Room>> getRoomsByWarden(@PathVariable String wardenId) {
        return ResponseEntity.ok(wardenService.getRoomsByWarden(wardenId));
    }
}
