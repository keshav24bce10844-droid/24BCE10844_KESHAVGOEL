package com.hostel.hostel_management.repository;

import com.hostel.hostel_management.model.Warden;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface WardenRepository extends MongoRepository<Warden, String> {
}
