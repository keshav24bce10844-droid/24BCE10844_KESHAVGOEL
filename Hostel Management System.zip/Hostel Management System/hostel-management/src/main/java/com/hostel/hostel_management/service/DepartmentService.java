package com.hostel.hostel_management.service;

import com.hostel.hostel_management.model.Department;
import com.hostel.hostel_management.model.Staff;
import com.hostel.hostel_management.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface DepartmentService {

    Department createDepartment(Department department);

    Page<Department> getAllDepartments(Pageable pageable);

    Department getDepartmentById(String id);

    Department updateDepartment(String id, Department department);

    void deleteDepartment(String id);

    List<Student> getStudentsByDepartment(String departmentId);

    List<Staff> getStaffByDepartment(String departmentId);
}
