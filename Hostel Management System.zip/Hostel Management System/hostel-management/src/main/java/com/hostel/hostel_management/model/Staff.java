package com.hostel.hostel_management.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "staff")
public class Staff {

    @Id
    private String id;

    @NotBlank(message = "Staff name is required")
    private String name;

    @NotBlank(message = "Staff phone is required")
    private String phone;

    @NotBlank(message = "Staff email is required")
    @Email(message = "Staff email must be valid")
    private String email;

    @NotBlank(message = "Staff role is required")
    private String role;

    @NotBlank(message = "Department id is required")
    private String departmentId;
}
