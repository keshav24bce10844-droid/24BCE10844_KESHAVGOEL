package com.hostel.hostel_management.service.impl;

import com.hostel.hostel_management.exception.BadRequestException;
import com.hostel.hostel_management.exception.ResourceNotFoundException;
import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Warden;
import com.hostel.hostel_management.repository.RoomRepository;
import com.hostel.hostel_management.repository.StaffRepository;
import com.hostel.hostel_management.repository.WardenRepository;
import com.hostel.hostel_management.service.WardenService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class WardenServiceImpl implements WardenService {

    private final WardenRepository wardenRepository;
    private final RoomRepository roomRepository;
    private final StaffRepository staffRepository;

    @Override
    public Warden createWarden(Warden warden) {
        validateStaffIfPresent(warden.getStaffId());
        return wardenRepository.save(warden);
    }

    @Override
    public Page<Warden> getAllWardens(Pageable pageable) {
        return wardenRepository.findAll(pageable);
    }

    @Override
    public Warden getWardenById(String id) {
        return findWarden(id);
    }

    @Override
    public Warden updateWarden(String id, Warden warden) {
        Warden existingWarden = findWarden(id);
        existingWarden.setName(warden.getName());
        existingWarden.setPhone(warden.getPhone());
        existingWarden.setEmail(warden.getEmail());
        validateStaffIfPresent(warden.getStaffId());
        existingWarden.setStaffId(warden.getStaffId());
        return wardenRepository.save(existingWarden);
    }

    @Override
    public void deleteWarden(String id) {
        Warden warden = findWarden(id);
        if (!roomRepository.findByWardenId(id).isEmpty()) {
            throw new BadRequestException("Cannot delete warden while rooms are assigned to them");
        }
        wardenRepository.delete(warden);
    }

    @Override
    public List<Room> getRoomsByWarden(String wardenId) {
        findWarden(wardenId);
        return roomRepository.findByWardenId(wardenId);
    }

    private Warden findWarden(String id) {
        return wardenRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warden not found with id: " + id));
    }

    private void validateStaffIfPresent(String staffId) {
        if (staffId != null && !staffId.isBlank() && !staffRepository.existsById(staffId)) {
            throw new ResourceNotFoundException("Staff not found with id: " + staffId);
        }
    }
}
