package com.hostel.hostel_management.controller;

import com.hostel.hostel_management.dto.ComplaintRequest;
import com.hostel.hostel_management.model.Book;
import com.hostel.hostel_management.model.Complaint;
import com.hostel.hostel_management.model.Student;
import com.hostel.hostel_management.service.BookService;
import com.hostel.hostel_management.service.ComplaintService;
import com.hostel.hostel_management.service.StudentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;
    private final ComplaintService complaintService;
    private final BookService bookService;

    @PostMapping
    public ResponseEntity<Student> createStudent(@Valid @RequestBody Student student) {
        return ResponseEntity.status(HttpStatus.CREATED).body(studentService.createStudent(student));
    }

    @GetMapping
    public ResponseEntity<Page<Student>> getAllStudents(Pageable pageable) {
        return ResponseEntity.ok(studentService.getAllStudents(pageable));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable String id) {
        return ResponseEntity.ok(studentService.getStudentById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable String id, @Valid @RequestBody Student student) {
        return ResponseEntity.ok(studentService.updateStudent(id, student));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable String id) {
        studentService.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{studentId}/allocate/{roomId}")
    public ResponseEntity<Student> allocateStudentToRoom(
            @PathVariable String studentId,
            @PathVariable String roomId) {
        return ResponseEntity.ok(studentService.allocateStudentToRoom(studentId, roomId));
    }

    @PostMapping("/{studentId}/complaints")
    public ResponseEntity<Complaint> raiseComplaint(
            @PathVariable String studentId,
            @Valid @RequestBody ComplaintRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(complaintService.raiseComplaint(studentId, request));
    }

    @GetMapping("/{studentId}/complaints")
    public ResponseEntity<List<Complaint>> getComplaintsOfStudent(@PathVariable String studentId) {
        return ResponseEntity.ok(complaintService.getComplaintsByStudent(studentId));
    }

    @GetMapping("/{studentId}/books")
    public ResponseEntity<List<Book>> getBooksIssuedToStudent(@PathVariable String studentId) {
        return ResponseEntity.ok(bookService.getBooksIssuedToStudent(studentId));
    }
}
