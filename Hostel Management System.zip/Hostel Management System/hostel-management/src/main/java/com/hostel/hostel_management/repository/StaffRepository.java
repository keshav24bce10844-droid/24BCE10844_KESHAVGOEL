package com.hostel.hostel_management.repository;

import com.hostel.hostel_management.model.Staff;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface StaffRepository extends MongoRepository<Staff, String> {

    List<Staff> findByDepartmentId(String departmentId);
}
