package com.hostel.hostel_management.controller;

import com.hostel.hostel_management.model.Book;
import com.hostel.hostel_management.service.BookService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;

    @PostMapping
    public ResponseEntity<Book> createBook(@Valid @RequestBody Book book) {
        return ResponseEntity.status(HttpStatus.CREATED).body(bookService.createBook(book));
    }

    @GetMapping
    public ResponseEntity<Page<Book>> getAllBooks(Pageable pageable) {
        return ResponseEntity.ok(bookService.getAllBooks(pageable));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable String id) {
        return ResponseEntity.ok(bookService.getBookById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable String id, @Valid @RequestBody Book book) {
        return ResponseEntity.ok(bookService.updateBook(id, book));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable String id) {
        bookService.deleteBook(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{bookId}/issue/student/{studentId}")
    public ResponseEntity<Book> issueBookToStudent(@PathVariable String bookId, @PathVariable String studentId) {
        return ResponseEntity.ok(bookService.issueBookToStudent(bookId, studentId));
    }

    @PostMapping("/{bookId}/return/student/{studentId}")
    public ResponseEntity<Book> returnBookFromStudent(@PathVariable String bookId, @PathVariable String studentId) {
        return ResponseEntity.ok(bookService.returnBookFromStudent(bookId, studentId));
    }

    @PostMapping("/{bookId}/assign/staff/{staffId}")
    public ResponseEntity<Book> assignBookToStaff(@PathVariable String bookId, @PathVariable String staffId) {
        return ResponseEntity.ok(bookService.assignBookToStaff(bookId, staffId));
    }

    @PostMapping("/{bookId}/unassign/staff/{staffId}")
    public ResponseEntity<Book> unassignBookFromStaff(@PathVariable String bookId, @PathVariable String staffId) {
        return ResponseEntity.ok(bookService.unassignBookFromStaff(bookId, staffId));
    }
}
