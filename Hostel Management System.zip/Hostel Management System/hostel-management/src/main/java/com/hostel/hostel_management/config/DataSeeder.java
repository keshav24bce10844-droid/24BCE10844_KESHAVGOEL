package com.hostel.hostel_management.config;

import com.hostel.hostel_management.model.Book;
import com.hostel.hostel_management.model.Complaint;
import com.hostel.hostel_management.model.ComplaintStatus;
import com.hostel.hostel_management.model.Department;
import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Staff;
import com.hostel.hostel_management.model.Student;
import com.hostel.hostel_management.model.Warden;
import com.hostel.hostel_management.repository.BookRepository;
import com.hostel.hostel_management.repository.ComplaintRepository;
import com.hostel.hostel_management.repository.DepartmentRepository;
import com.hostel.hostel_management.repository.RoomRepository;
import com.hostel.hostel_management.repository.StaffRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.repository.WardenRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
@RequiredArgsConstructor
@ConditionalOnProperty(name = "app.seed.enabled", havingValue = "true", matchIfMissing = true)
public class DataSeeder implements CommandLineRunner {

    private final DepartmentRepository departmentRepository;
    private final StaffRepository staffRepository;
    private final WardenRepository wardenRepository;
    private final RoomRepository roomRepository;
    private final StudentRepository studentRepository;
    private final ComplaintRepository complaintRepository;
    private final BookRepository bookRepository;

    @Override
    public void run(String... args) {
        if (departmentRepository.count() > 0) {
            return;
        }

        Department cse = departmentRepository.save(Department.builder()
                .id("dept-cse")
                .name("Computer Science")
                .code("CSE")
                .build());
        Department ece = departmentRepository.save(Department.builder()
                .id("dept-ece")
                .name("Electronics and Communication")
                .code("ECE")
                .build());

        Staff wardenStaff = staffRepository.save(Staff.builder()
                .id("staff-warden-1")
                .name("Ravi Kumar")
                .phone("9876543210")
                .email("ravi@example.com")
                .role("WARDEN")
                .departmentId(cse.getId())
                .build());
        Staff librarian = staffRepository.save(Staff.builder()
                .id("staff-library-1")
                .name("Neha Sharma")
                .phone("9876500001")
                .email("neha@example.com")
                .role("LIBRARIAN")
                .departmentId(ece.getId())
                .build());

        Warden warden = wardenRepository.save(Warden.builder()
                .id("warden-1")
                .name("Ravi Kumar")
                .phone("9876543210")
                .email("ravi@example.com")
                .staffId(wardenStaff.getId())
                .build());

        Room room = roomRepository.save(Room.builder()
                .id("room-a101")
                .roomNumber("A101")
                .capacity(2)
                .occupiedBeds(1)
                .wardenId(warden.getId())
                .build());

        Student student = studentRepository.save(Student.builder()
                .id("student-1")
                .name("Keshav")
                .email("keshav@example.com")
                .phone("9876501234")
                .roomId(room.getId())
                .departmentId(cse.getId())
                .build());
        studentRepository.save(Student.builder()
                .id("student-2")
                .name("Ananya")
                .email("ananya@example.com")
                .phone("9876505678")
                .departmentId(ece.getId())
                .build());

        complaintRepository.save(Complaint.builder()
                .id("complaint-1")
                .description("Fan is not working")
                .status(ComplaintStatus.OPEN)
                .studentId(student.getId())
                .build());

        bookRepository.save(Book.builder()
                .id("book-java")
                .title("Effective Java")
                .author("Joshua Bloch")
                .isbn("9780134685991")
                .totalCopies(3)
                .issuedStudentIds(Set.of(student.getId()))
                .assignedStaffIds(Set.of(librarian.getId()))
                .build());
    }
}
