package com.hostel.hostel_management.service;

import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface RoomService {

    Room createRoom(Room room);

    Page<Room> getAllRooms(Pageable pageable);

    Room getRoomById(String id);

    Room updateRoom(String id, Room room);

    void deleteRoom(String id);

    List<Student> getStudentsByRoom(String roomId);
}
