package com.hostel.hostel_management.model;

public enum ComplaintStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    REJECTED
}
