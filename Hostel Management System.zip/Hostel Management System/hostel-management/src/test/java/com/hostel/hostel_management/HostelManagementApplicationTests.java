package com.hostel.hostel_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "app.seed.enabled=false")
class HostelManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
