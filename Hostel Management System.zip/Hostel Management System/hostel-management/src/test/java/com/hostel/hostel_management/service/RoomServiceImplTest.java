package com.hostel.hostel_management.service;

import com.hostel.hostel_management.exception.BadRequestException;
import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Student;
import com.hostel.hostel_management.repository.RoomRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.repository.WardenRepository;
import com.hostel.hostel_management.service.impl.RoomServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RoomServiceImplTest {

    @Mock
    private RoomRepository roomRepository;

    @Mock
    private StudentRepository studentRepository;

    @Mock
    private WardenRepository wardenRepository;

    @InjectMocks
    private RoomServiceImpl roomService;

    @Test
    void deleteRoomWithAllocatedStudentsThrowsBadRequestException() {
        Room room = Room.builder().id("room-1").roomNumber("A101").build();
        Student student = Student.builder().id("student-1").roomId("room-1").build();

        when(roomRepository.findById("room-1")).thenReturn(Optional.of(room));
        when(studentRepository.findByRoomId("room-1")).thenReturn(List.of(student));

        assertThatThrownBy(() -> roomService.deleteRoom("room-1"))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("Cannot delete room");
    }
}
