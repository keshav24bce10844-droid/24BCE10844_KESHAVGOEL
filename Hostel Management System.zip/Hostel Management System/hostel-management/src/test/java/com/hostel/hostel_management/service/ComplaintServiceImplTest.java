package com.hostel.hostel_management.service;

import com.hostel.hostel_management.model.Complaint;
import com.hostel.hostel_management.model.ComplaintStatus;
import com.hostel.hostel_management.repository.ComplaintRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.service.impl.ComplaintServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ComplaintServiceImplTest {

    @Mock
    private ComplaintRepository complaintRepository;

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private ComplaintServiceImpl complaintService;

    @Test
    void updateComplaintStatusUsesEnumValue() {
        Complaint complaint = Complaint.builder()
                .id("complaint-1")
                .description("Fan is not working")
                .status(ComplaintStatus.OPEN)
                .studentId("student-1")
                .build();

        when(complaintRepository.findById("complaint-1")).thenReturn(Optional.of(complaint));
        when(complaintRepository.save(any(Complaint.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Complaint updatedComplaint = complaintService.updateComplaintStatus("complaint-1", ComplaintStatus.RESOLVED);

        assertThat(updatedComplaint.getStatus()).isEqualTo(ComplaintStatus.RESOLVED);
    }
}
