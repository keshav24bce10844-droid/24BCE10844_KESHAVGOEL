package com.hostel.hostel_management.service;

import com.hostel.hostel_management.exception.BadRequestException;
import com.hostel.hostel_management.model.Room;
import com.hostel.hostel_management.model.Student;
import com.hostel.hostel_management.repository.DepartmentRepository;
import com.hostel.hostel_management.repository.RoomRepository;
import com.hostel.hostel_management.repository.StudentRepository;
import com.hostel.hostel_management.service.impl.StudentServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StudentServiceImplTest {

    @Mock
    private StudentRepository studentRepository;

    @Mock
    private RoomRepository roomRepository;

    @Mock
    private DepartmentRepository departmentRepository;

    @InjectMocks
    private StudentServiceImpl studentService;

    @Test
    void allocateStudentToFullRoomThrowsBadRequestException() {
        Student student = Student.builder().id("student-1").name("Keshav").build();
        Room room = Room.builder().id("room-1").roomNumber("A101").capacity(1).occupiedBeds(1).build();

        when(studentRepository.findById("student-1")).thenReturn(Optional.of(student));
        when(roomRepository.findById("room-1")).thenReturn(Optional.of(room));

        assertThatThrownBy(() -> studentService.allocateStudentToRoom("student-1", "room-1"))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("Room capacity exceeded");
    }

    @Test
    void allocateStudentToRoomIncrementsOccupiedBeds() {
        Student student = Student.builder().id("student-1").name("Keshav").build();
        Room room = Room.builder().id("room-1").roomNumber("A101").capacity(2).occupiedBeds(0).build();

        when(studentRepository.findById("student-1")).thenReturn(Optional.of(student));
        when(roomRepository.findById("room-1")).thenReturn(Optional.of(room));
        when(studentRepository.save(any(Student.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Student allocatedStudent = studentService.allocateStudentToRoom("student-1", "room-1");

        assertThat(allocatedStudent.getRoomId()).isEqualTo("room-1");
        assertThat(room.getOccupiedBeds()).isEqualTo(1);
        verify(roomRepository).save(room);
    }
}
