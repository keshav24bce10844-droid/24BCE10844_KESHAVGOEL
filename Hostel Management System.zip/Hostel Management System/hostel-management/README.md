# Hostel Management System API

Backend-only Spring Boot 3 API using Java 17, MongoDB, Maven, Lombok, validation, and Swagger/OpenAPI.

## Run

Start MongoDB locally on:

```text
mongodb://localhost:27017
```

Then run the API:

```powershell
.\mvnw.cmd spring-boot:run
```

The app connects to:

```text
mongodb://localhost:27017/hosteldb
```

Swagger UI:

```text
http://localhost:8080/swagger-ui.html
```

## Main APIs

- `POST /departments`, `GET /departments`
- `POST /staff`, `GET /staff`
- `POST /wardens`, `GET /wardens`
- `POST /rooms`, `GET /rooms`
- `POST /students`, `GET /students`
- `POST /books`, `GET /books`
- `POST /complaints`, `GET /complaints`

Paginated list endpoints support query params like:

```text
GET /students?page=0&size=10&sort=name,asc
```

## Demo Flow

Seed data is inserted automatically on first startup if no departments exist.

Useful seeded IDs:

- Department: `dept-cse`
- Staff: `staff-warden-1`, `staff-library-1`
- Warden: `warden-1`
- Room: `room-a101`
- Student: `student-1`
- Book: `book-java`
- Complaint: `complaint-1`

Example requests:

```text
GET /departments
GET /rooms/room-a101/students
POST /students/student-1/allocate/room-a101
POST /books/book-java/issue/student/student-2
POST /books/book-java/assign/staff/staff-library-1
PATCH /complaints/complaint-1/status
```

Complaint status body:

```json
{
  "status": "RESOLVED"
}
```

Allowed statuses:

```text
OPEN, IN_PROGRESS, RESOLVED, REJECTED
```

## Relationships Covered

- One-to-one style: `Warden.staffId`
- One-to-many: `Warden -> Rooms`, `Department -> Students`, `Department -> Staff`
- Many-to-one: `Student.roomId`, `Room.wardenId`, `Staff.departmentId`
- Many-to-many: `Book.issuedStudentIds`, `Book.assignedStaffIds`

## Test

```powershell
.\mvnw.cmd test
```
